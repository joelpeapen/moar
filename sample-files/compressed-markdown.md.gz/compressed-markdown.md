# Pro Tip

Don't run with scissors.
